package com.example.correcaojogo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText edtJog1, edtJog2, edtNum1, edtNum2;
        edtJog1 = findViewById(R.id.edt_jog1);
        edtJog2 = findViewById(R.id.edt_jog2);
        edtNum1 = findViewById(R.id.edt_num1);
        edtNum2 = findViewById(R.id.edt_num2);
        Button btnJogar = findViewById(R.id.btn_jogar);
        TextView tvwResultado = findViewById(R.id.tvw_resultado);
        btnJogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strJog1 = edtJog1.getText().toString();
                String strJog2 = edtJog2.getText().toString();
                int num1 = Integer.parseInt(edtNum1.getText().toString());
                int num2 = Integer.parseInt(edtNum2.getText().toString());
                Random random = new Random();
                int resultado = random.nextInt(11);
                tvwResultado.setText("Número sorteado" + resultado);
            }
        });
    }
}